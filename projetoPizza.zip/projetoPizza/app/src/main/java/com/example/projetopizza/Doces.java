package com.example.projetopizza;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Doces extends AppCompatActivity {
    private ListView nomedoce;
    SQLiteDatabase bancoDadosDoces;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doces);

        try {

            ArrayList<String> doces = new ArrayList<>();
            nomedoce = findViewById(R.id.IDdoce);

            SQLiteDatabase bancoDadosDoces = openOrCreateDatabase("app", MODE_PRIVATE, null);

            bancoDadosDoces.execSQL("DROP TABLE IF EXISTS DOCE");

            //tabela
            bancoDadosDoces.execSQL("CREATE TABLE IF NOT EXISTS DOCE( id INTEGER PRIMARY KEY AUTOINCREMENT, sabor VARCHAR)");

            //Inserir dados
            bancoDadosDoces.execSQL("INSERT INTO DOCE (sabor) VALUES ('Amendoin Doce')");
            bancoDadosDoces.execSQL("INSERT INTO DOCE (sabor) VALUES ('Geleia')");
            bancoDadosDoces.execSQL("INSERT INTO DOCE (sabor) VALUES ('Gelatina')");

            ArrayAdapter adptador3 = new ArrayAdapter<>(
                    getApplicationContext(),
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    doces
            );

            nomedoce.setAdapter(adptador3);

            Cursor cursor = bancoDadosDoces.rawQuery("SELECT * FROM DOCE ", null);

            int indiceColunaNome = cursor.getColumnIndex("sabor");
            int indiceColunaId = cursor.getColumnIndex("id");

            cursor.moveToFirst();

            while (cursor != null) {
                String doce = cursor.getString(indiceColunaNome);
                doces.add(doce);

                cursor.moveToNext();

            }

        }catch(Exception e){
            e.printStackTrace();
        }

    }
}
