package com.example.projetopizza;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Combos extends AppCompatActivity {
    private ListView nomecombo;
    SQLiteDatabase bancoDadosCombo;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combos);
        try {

            ArrayList<String> combos = new ArrayList<>();
            nomecombo = findViewById(R.id.IDcombo);


            SQLiteDatabase bancoDadosCombo = openOrCreateDatabase("app", MODE_PRIVATE, null);

            bancoDadosCombo.execSQL("DROP TABLE IF EXISTS COMBO");

            //tabela
            bancoDadosCombo.execSQL("CREATE TABLE IF NOT EXISTS COMBO( id INTEGER PRIMARY KEY AUTOINCREMENT, sabor VARCHAR)");

            //Inserir dados
            bancoDadosCombo.execSQL("INSERT INTO COMBO (sabor) VALUES ('Bacon com Coca Cola')");
            bancoDadosCombo.execSQL("INSERT INTO COMBO (sabor) VALUES ('Pizza G com Coca Cola 2l')");
            bancoDadosCombo.execSQL("INSERT INTO COMBO (sabor) VALUES ('Batata frita com Pizza M')");

            ArrayAdapter adptador4 = new ArrayAdapter<>(
                    getApplicationContext(),
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    combos
            );

            nomecombo.setAdapter(adptador4);

            Cursor cursor = bancoDadosCombo.rawQuery("SELECT * FROM COMBO ", null);

            int indiceColunaNome = cursor.getColumnIndex("sabor");
            int indiceColunaId = cursor.getColumnIndex("id");

            cursor.moveToFirst();

            while (cursor!= null) {
                String combo = cursor.getString(indiceColunaNome);
                combos.add(combo);

                cursor.moveToNext();
            }

        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
