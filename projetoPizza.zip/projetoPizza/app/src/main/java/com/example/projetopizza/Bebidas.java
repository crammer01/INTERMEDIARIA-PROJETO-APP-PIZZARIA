package com.example.projetopizza;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Bebidas extends AppCompatActivity {
    private ListView nomebebida;
    SQLiteDatabase bancoDadosBebida;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bebidas);

        try {
            ArrayList<String> bebida = new ArrayList<>();
            nomebebida = findViewById(R.id.IDbebida);

            SQLiteDatabase bancoDadosBebida = openOrCreateDatabase("app", MODE_PRIVATE, null);

            bancoDadosBebida.execSQL("DROP TABLE IF EXISTS BEBIDA");

            //tabela
            bancoDadosBebida.execSQL("CREATE TABLE IF NOT EXISTS BEBIDA( id INTEGER PRIMARY KEY AUTOINCREMENT, sabor VARCHAR)");

            //Inserir dados
            bancoDadosBebida.execSQL("INSERT INTO BEBIDA (sabor) VALUES ('Coca Cola lata')");
            bancoDadosBebida.execSQL("INSERT INTO BEBIDA (sabor) VALUES ('Coca Cola 500ml')");
            bancoDadosBebida.execSQL("INSERT INTO BEBIDA (sabor) VALUES ('Coca Cola 1l')");
            bancoDadosBebida.execSQL("INSERT INTO BEBIDA (sabor) VALUES ('Coca Cola 1,5l')");
            bancoDadosBebida.execSQL("INSERT INTO BEBIDA (sabor) VALUES ('Coca Cola 2l')");
            bancoDadosBebida.execSQL("INSERT INTO BEBIDA (sabor) VALUES ('Tuchau lata')");
            bancoDadosBebida.execSQL("INSERT INTO BEBIDA (sabor) VALUES ('Pepsi lata')");
            bancoDadosBebida.execSQL("INSERT INTO BEBIDA (sabor) VALUES ('Pepsi 2l')");

            ArrayAdapter adptador5 = new ArrayAdapter<>(
                    getApplicationContext(),
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    bebida
            );

            nomebebida.setAdapter(adptador5);

            Cursor cursor = bancoDadosBebida.rawQuery("SELECT * FROM BEBIDA ", null);

            int indiceColunaNome = cursor.getColumnIndex("sabor");
            int indiceColunaId = cursor.getColumnIndex("id");

            cursor.moveToFirst();

            while (cursor != null) {
                String beb = cursor.getString(indiceColunaNome);
                bebida.add(beb);

                cursor.moveToNext();
            }

        }catch(Exception e){
            e.printStackTrace();
        }

    }
}
