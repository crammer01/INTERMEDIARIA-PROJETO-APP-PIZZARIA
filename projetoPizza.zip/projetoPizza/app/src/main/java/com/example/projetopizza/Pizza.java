package com.example.projetopizza;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Pizza extends AppCompatActivity {

    private ListView nomepizza;
    SQLiteDatabase bancoDadosPizza;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza);
        try {
            nomepizza = findViewById(R.id.IDpizza);
            ArrayList<String> pizzas = new ArrayList<String>();

            SQLiteDatabase bancoDadosPizza = openOrCreateDatabase("app", MODE_PRIVATE, null);

            bancoDadosPizza.execSQL("DROP TABLE IF EXISTS PIZZA");

            //tabela
            bancoDadosPizza.execSQL("CREATE TABLE IF NOT EXISTS PIZZA( id INTEGER PRIMARY KEY AUTOINCREMENT, sabor VARCHAR (30))");

            //Inserir dados
            bancoDadosPizza.execSQL("INSERT INTO PIZZA (sabor) VALUES ('Bacon com calabresa')");
            bancoDadosPizza.execSQL("INSERT INTO PIZZA (sabor) VALUES ('franco com catupiri')");
            bancoDadosPizza.execSQL("INSERT INTO PIZZA (sabor) VALUES ('moda da casa')");
            bancoDadosPizza.execSQL("INSERT INTO PIZZA (sabor) VALUES ('portuguesa')");

            ArrayAdapter adptador2 = new ArrayAdapter<>(
                    getApplicationContext(),
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    pizzas
            );

            nomepizza.setAdapter(adptador2);

            Cursor cursor = bancoDadosPizza.rawQuery("SELECT * FROM PIZZA ", null);

            int indiceColunaNome = cursor.getColumnIndex("sabor");
            int indiceColunaId = cursor.getColumnIndex("id");

            cursor.moveToFirst();

            while (cursor!= null) {
                String pizza = cursor.getString(indiceColunaNome);
                pizzas.add(pizza);

                cursor.moveToNext();
            }

        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
