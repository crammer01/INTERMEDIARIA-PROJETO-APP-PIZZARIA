package com.example.projetopizza;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private ImageView btn_pizza;
    private ImageView btn_combo;
    private ImageView btn_bebidas;
    private ImageView btn_sobremesas;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_pizza = findViewById(R.id.idpizza);
        btn_combo = findViewById(R.id.idcombo);
        btn_bebidas = findViewById(R.id.idbebida);
        btn_sobremesas = findViewById(R.id.idsobremesa);

            btn_pizza.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intentPizza = new Intent(MainActivity.this, Pizza.class);
                        startActivity(intentPizza);
                }
            });

            btn_combo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intentCombo = new Intent(MainActivity.this, Combos.class);
                        startActivity(intentCombo);
                }
            });

            btn_bebidas.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intentbeb = new Intent(MainActivity.this, Bebidas.class);
                    startActivity(intentbeb);
                }
            });

            btn_sobremesas.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intnetSobremesas = new Intent(MainActivity.this, Doces.class);
                }
            });
    }
}
