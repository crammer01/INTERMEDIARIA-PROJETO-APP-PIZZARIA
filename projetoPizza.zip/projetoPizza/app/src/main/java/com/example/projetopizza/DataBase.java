package com.example.projetopizza;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataBase extends SQLiteOpenHelper {

    private static final int VERSAO_BANCO = 1;
    private static final String BANCO_PIZZARIA = "bd_pizzaria";

    private static final String TABELA_PIZZA = "tb_pizza";
    private static final String TABELA_COMBO = "tb_combo";
    private static final String TABELA_DOCES = "tb_doces";
    private static final String TABELA_BEBIDA = "tb_bebida";

    private static final String COLUNA_ID = "ID";

    private static final String COLUNA_PIZZA = "pizza";
    private static final String COLUNA_COMBO = "combo";
    private static final String COLUNA_DOCE = "doce";
    private static final String COLUNA_BEBIDA = "bebida";

    public DataBase(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, BANCO_PIZZARIA, null, VERSAO_BANCO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String COLUNA_QUERY = "CREATE TABLE" + TABELA_PIZZA + "(" + COLUNA_ID + " INTEGER PRIMARY KEY, " + COLUNA_PIZZA + " TEXT" + ")";
        String COLUNA_QUERY1 = "CREATE TABLE" + TABELA_COMBO + "(" + COLUNA_ID + " INTEGER PRIMARY KEY, " + COLUNA_COMBO + " TEXT" + ")";
        String COLUNA_QUERY2 = "CREATE TABLE" + TABELA_DOCES + "(" + COLUNA_ID + " INTEGER PRIMARY KEY, " + COLUNA_DOCE + " TEXT" + ")";
        String COLUNA_QUERY3 = "CREATE TABLE" + TABELA_BEBIDA + "(" + COLUNA_ID + " INTEGER PRIMARY KEY, " + COLUNA_BEBIDA + " TEXT" + ")";

        db.execSQL(COLUNA_QUERY);
        db.execSQL(COLUNA_QUERY1);
        db.execSQL(COLUNA_QUERY2);
        db.execSQL(COLUNA_QUERY3);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }
}
